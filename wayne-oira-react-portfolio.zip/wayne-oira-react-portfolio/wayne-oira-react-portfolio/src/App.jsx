import React, { useState } from 'react'
import waynePhoto from './assets/image.jpg'

const projects = [
  {
    number: '01',
    title: 'Creative Design & Branding',
    type: 'GRAPHIC DESIGN',
    description:
      'Visual materials created for youth activities, pageants, community programs, social media campaigns, personal branding, and organizational projects.',
    tags: ['Graphic Design', 'Branding', 'Social Media', 'Layout'],
  },
  {
    number: '02',
    title: 'Youth & Community Initiatives',
    type: 'PUBLIC SERVICE',
    description:
      'Community-centered initiatives and activities focused on youth development, education, culture, wellness, emergency response, and meaningful community participation.',
    tags: ['Youth Development', 'Community', 'Events', 'Public Service'],
  },
  {
    number: '03',
    title: 'Online English Teaching',
    type: 'EDUCATION',
    description:
      'Online language teaching experience focused on helping learners develop English communication skills through engaging, supportive, and learner-centered classes.',
    tags: ['ESL Teaching', 'Communication', 'Education', 'Online Teaching'],
  },
]

const skills = [
  ['Graphic Design', 'Creative'],
  ['Visual Communication', 'Creative'],
  ['Branding & Layout', 'Design'],
  ['Social Media Design', 'Digital'],
  ['English Teaching', 'Education'],
  ['Public Speaking', 'Communication'],
  ['Event Organization', 'Leadership'],
  ['Community Service', 'Public Service'],
]

const education = [
  {
    period: '2011 — 2017',
    title: 'Elementary',
    organization: 'Gulanggulang Elementary School',
    details: 'Completed elementary education.',
  },
  {
    period: '2017 — 2021',
    title: 'Junior High School',
    organization: 'Quezon National High School',
    details: 'Completed junior high school education.',
  },
  {
    period: '2021 — 2023',
    title: 'Senior High School — HUMSS',
    organization: 'Quezon National High School',
    details:
      'Humanities and Social Sciences strand. Developed interests in communication, society, leadership, and community involvement.',
  },
  {
    period: '2023 — Present',
    title: 'Bachelor of Science in Information Technology',
    organization: 'Dalubhasaan ng Lungsod ng Lucena',
    details:
      'Currently pursuing a BSIT degree while balancing professional work, creative projects, and community service.',
  },
]

const leadership = [
  {
    period: '2026 — Present',
    title: 'President',
    organization: 'DLL Institutional Community Extension Services',
    details:
      'Leading community extension initiatives and helping coordinate student-led service and community activities.',
  },
  {
    period: '2023 — Present',
    title: 'Domoit Community Leader',
    organization: 'DLL Institutional Community Extension Services',
    details:
      'Serving as a community leader for Domoit-focused activities and initiatives.',
  },
  {
    period: '2023 — 2024',
    title: 'Auditor',
    organization: 'DLL Institutional Community Extension Services',
    details:
      'Served as an organization auditor and supported organizational activities and accountability.',
  },
  {
    period: '2023 — 2024',
    title: 'Public Information Officer',
    organization: 'IT Paradigm',
    details:
      'Handled information dissemination and communication-related responsibilities.',
  },
  {
    period: '2023 — 2024',
    title: 'Secretary',
    organization: 'DLL Supreme Student Council',
    details:
      'Supported student leadership activities, documentation, communication, and organizational coordination.',
  },
  {
    period: '2023 — Present',
    title: 'SK Member',
    organization: 'Sangguniang Kabataan of Brgy. Domoit',
    details:
      'Served in youth governance and community initiatives, including education, culture, and budget monitoring responsibilities.',
  },
]

const affiliations = [
  'Concerned Youth of Domoit',
  'Sangguniang Kabataan Wellness and Development',
  'Sangguniang Kabataan Emergency Response Team',
  'Luntian',
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  const closeMenu = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      {/* =====================================================
          NAVIGATION
      ===================================================== */}

      <header className="navbar">
        <a className="brand" href="#home" onClick={closeMenu}>
          <span className="brand-mark"></span>
          <span>Wayne Oira</span>
        </a>

        <button
          className="menu-button"
          type="button"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          className={`nav-links ${menuOpen ? 'open' : ''}`}
          aria-label="Primary navigation"
        >
          {[
            'About',
            'Skills',
            'Experience',
            'Education',
            'Projects',
            'Affiliations',
            'Contact',
          ].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              onClick={closeMenu}
            >
              {item}
            </a>
          ))}
        </nav>
      </header>

      <main>

        {/* =====================================================
            HERO / LANDING PAGE
        ===================================================== */}

        <section className="hero section" id="home">
          <div className="hero-copy">

            <p className="eyebrow">
              GRAPHIC DESIGNER • LANGUAGE TEACHER • PUBLIC SERVANT
            </p>

            <h1>
              Creating with <span>purpose, people, and passion.</span>
            </h1>

            <p className="hero-text">
              I’m Wayne Oira — a graphic designer, online language teacher,
              public servant, and BS Information Technology student. I create
              visual materials, teach English to learners online, and actively
              contribute to youth and community initiatives.
            </p>

            <div className="hero-actions">
              <a className="button primary" href="#projects">
                View My Work
              </a>

              <a className="button secondary" href="#contact">
                Let’s Connect
              </a>
            </div>

            <div className="quick-facts" aria-label="Quick facts">
              <span>Graphic Design</span>
              <span>Online Language Teacher</span>
              <span>Public Servant</span>
              <span>Civil Service Professional</span>
            </div>

          </div>

          {/* HERO PHOTO */}

          <div className="hero-card">
            <div className="portrait-placeholder">
              <img src={waynePhoto} alt="Wayne Oira" />
            </div>

            <div className="hero-card-bottom">
              <div>
                <p className="mini-label">CURRENT FOCUS</p>
                <h2>Creative & Community Work</h2>
              </div>

              <span
                className="status-dot"
                title="Open to learning and opportunities"
              />
            </div>
          </div>
        </section>

        {/* =====================================================
            ABOUT
        ===================================================== */}

        <section className="section about" id="about">
          <div className="section-heading">
            <p className="eyebrow">ABOUT ME</p>

            <h2>
              A working student, educator, public servant, and creative.
            </h2>
          </div>

          <div className="about-profile">
            <div className="profile-item">
              <span className="profile-number">01</span>
              <div>
                <span className="profile-label">EDUCATION</span>
                <h3>BSIT Student</h3>
                <p>Dalubhasaan ng Lungsod ng Lucena</p>
              </div>
            </div>

            <div className="profile-item">
              <span className="profile-number">02</span>
              <div>
                <span className="profile-label">PUBLIC SERVICE</span>
                <h3>SK Member</h3>
                <p>Sangguniang Kabataan of Brgy. Domoit</p>
              </div>
            </div>

            <div className="profile-item">
              <span className="profile-number">03</span>
              <div>
                <span className="profile-label">PROFESSION</span>
                <h3>Language Teacher</h3>
                <p>Online English / ESL Teaching</p>
              </div>
            </div>

            <div className="profile-item">
              <span className="profile-number">04</span>
              <div>
                <span className="profile-label">PROFESSIONAL CREDENTIAL</span>
                <h3>Civil Service Professional</h3>
                <p>Professional Level Passer</p>
              </div>
            </div>
          </div>

          <div className="about-grid">
            <p>
              I am a working student balancing my studies with professional teaching
              and public service. I am currently pursuing a Bachelor of Science in
              Information Technology at Dalubhasaan ng Lungsod ng Lucena while working
              as an online language teacher and serving as an SK Member of Brgy. Domoit.
            </p>

            <p>
              My experiences in graphic design, education, youth leadership, and
              community service have shaped me into a versatile and people-oriented
              individual. I enjoy creating meaningful visual work, communicating with
              others, organizing activities, and contributing to projects that create
              value for the community.
            </p>
          </div>

          <div className="interest-row">
            {[
              'Graphic Design',
              'Visual Communication',
              'Teaching',
              'Leadership',
              'Public Service',
            ].map((interest) => (
              <span key={interest}>{interest}</span>
            ))}
          </div>
        </section>

        {/* =====================================================
            SKILLS
        ===================================================== */}

        <section className="section skills" id="skills">
          <div className="section-heading">
            <p className="eyebrow">SKILLS</p>

            <h2>
              Skills developed through creativity, work, and service.
            </h2>
          </div>

          <div className="skills-grid">
            {skills.map(([skill, category], index) => (
              <article className="skill-card" key={skill}>
                <span className="skill-number">
                  {String(index + 1).padStart(2, '0')}
                </span>

                <h3>{skill}</h3>

                <p>{category}</p>
              </article>
            ))}
          </div>
        </section>

        {/* =====================================================
            EXPERIENCE & SERVICE
        ===================================================== */}

        <section className="section experience" id="experience">
          <div className="section-heading">
            <p className="eyebrow">EXPERIENCE & SERVICE</p>

            <h2>
              Growing through work, leadership, and community involvement.
            </h2>
          </div>

          <div className="timeline">

            {/* ONLINE LANGUAGE TEACHER */}

            <article className="timeline-item">
              <div className="timeline-period">
                WORK
              </div>

              <div className="timeline-content">
                <h3>Online Language Teacher</h3>

                <p className="timeline-org">
                  Online ESL / Language Teaching
                </p>

                <p>
                  Teaching English to learners online while balancing
                  academic responsibilities. Focused on clear communication,
                  learner engagement, patience, and creating a positive
                  learning environment.
                </p>
              </div>
            </article>

            {/* LEADERSHIP */}

            {leadership.map((item) => (
              <article
                className="timeline-item"
                key={`${item.title}-${item.organization}`}
              >
                <div className="timeline-period">
                  {item.period}
                </div>

                <div className="timeline-content">
                  <h3>{item.title}</h3>

                  <p className="timeline-org">
                    {item.organization}
                  </p>

                  <p>{item.details}</p>
                </div>
              </article>
            ))}

          </div>
        </section>

        {/* =====================================================
            EDUCATION
        ===================================================== */}

        <section className="section experience" id="education">
          <div className="section-heading">
            <p className="eyebrow">EDUCATIONAL BACKGROUND</p>

            <h2>
              An academic journey built alongside real-world experience.
            </h2>
          </div>

          <div className="timeline">
            {education.map((item) => (
              <article className="timeline-item" key={item.title}>

                <div className="timeline-period">
                  {item.period}
                </div>

                <div className="timeline-content">
                  <h3>{item.title}</h3>

                  <p className="timeline-org">
                    {item.organization}
                  </p>

                  <p>{item.details}</p>
                </div>

              </article>
            ))}
          </div>
        </section>

        {/* =====================================================
            SELECTED WORK
        ===================================================== */}

        <section className="section projects" id="projects">
          <div className="section-heading project-heading">

            <div>
              <p className="eyebrow">SELECTED WORK</p>

              <h2>
                Creative work, teaching, and community initiatives.
              </h2>
            </div>

            <p className="heading-note">
              A snapshot of the work and experiences that represent my
              interests and capabilities.
            </p>

          </div>

          <div className="project-list">

            {projects.map((project) => (
              <article
                className="project-card"
                key={project.number}
              >

                <span className="project-number">
                  {project.number}
                </span>

                <div className="project-main">

                  <p className="project-type">
                    {project.type}
                  </p>

                  <h3>{project.title}</h3>

                  <p>{project.description}</p>

                  <div className="tag-list">
                    {project.tags.map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>

                </div>

                <span className="arrow" aria-hidden="true">
                  ↗
                </span>

              </article>
            ))}

          </div>
        </section>

        {/* =====================================================
            LEADERSHIP & AFFILIATIONS
        ===================================================== */}

        <section className="section about" id="affiliations">
          <div className="section-heading">

            <p className="eyebrow">
            LEADERSHIP & AFFILIATIONS
            </p>

            <h2>
              Organizations and communities that shaped my leadership journey.
            </h2>

          </div>

          <div className="interest-row">
            {affiliations.map((organization) => (
              <span key={organization}>
                {organization}
              </span>
            ))}
          </div>

          <div className="about-grid">

            <p>
              <strong>YOUTH ORGANIZATIONS — CO-FOUNDER</strong>
              <br />
              <br />

              Concerned Youth of Domoit
              <br />

              Sangguniang Kabataan Wellness and Development
              <br />

              Sangguniang Kabataan Emergency Response Team
              <br />

              Luntian
            </p>

            <p>
              <strong>SANGGUNIANG KABATAAN OF BRGY. DOMOIT</strong>
              <br />
              <br />

              SK Member
              <br />

              Chairperson — Education Sector (2023–2025)
              <br />

              Chairperson — Cultural Activities Sector
              (2025–Present)
              <br />

              Budget Monitoring Officer
            </p>

          </div>
        </section>

        {/* =====================================================
            CONTACT
        ===================================================== */}

        <section className="section contact" id="contact">
          <div className="contact-card">

            <p className="eyebrow">
              CONTACT
            </p>

            <h2>
              Let’s create, connect, and make an impact.
            </h2>

            <p>
              I’m interested in opportunities involving graphic design,
              creative projects, education, community initiatives, youth
              development, and meaningful collaborations.
            </p>

            <div className="contact-actions">

              <a
                className="button primary"
                href="mailto:your-email@example.com"
              >
                Email Me
              </a>

              <a
                className="button secondary"
                href="#home"
              >
                Back to Top ↑
              </a>

            </div>

          </div>
        </section>

      </main>

      {/* =====================================================
          FOOTER
      ===================================================== */}

      <footer className="footer">
        <p>
          © {new Date().getFullYear()} Wayne Oira. All rights reserved.
        </p>

        <p>
          Creativity • Service • Communication
        </p>
      </footer>

    </div>
  )
}

export default App