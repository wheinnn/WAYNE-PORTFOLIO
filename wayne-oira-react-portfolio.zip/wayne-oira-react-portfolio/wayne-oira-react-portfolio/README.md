# Wayne Oira React Portfolio

A responsive personal portfolio built with React and Vite.

## Requirements

- Node.js LTS
- VS Code
- Git Bash or the VS Code terminal

## Run locally

```bash
npm install
npm run dev
```

Then open the Local URL shown by Vite, normally `http://localhost:5173/`.

## Production check

```bash
npm run build
npm run preview
```

## Customize

Most personal content is in `src/App.jsx`.

- Replace the email address in the Contact section.
- Replace the `WO` portrait placeholder with your own photo if desired.
- Edit projects, skills, and experience directly in the arrays near the top of `src/App.jsx`.
- Main colors and layout are in `src/index.css`.

## Notes

The portfolio intentionally avoids external icon libraries and image assets, so the project can run after `npm install` without missing local assets.
